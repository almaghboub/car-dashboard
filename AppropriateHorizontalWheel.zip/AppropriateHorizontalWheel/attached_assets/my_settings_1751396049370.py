
# ملف الإعدادات الخاص بك - يمكنك تعديل هذا الملف بسهولة
# Your Custom Settings File - You can easily edit this file

# إعدادات التطبيق
APP_SETTINGS = {
    'app_name': 'نظام إدارة السيارات',  # اسم التطبيق
    'admin_password': 'admin123',        # كلمة مرور المدير
    'company_name': 'شركة السيارات المحدودة',  # اسم الشركة
    'contact_phone': '+966-50-123-4567',   # رقم الهاتف
    'contact_email': 'info@carcompany.com' # البريد الإلكتروني
}

# ألوان وتصميم الموقع
DESIGN_SETTINGS = {
    'primary_color': '#007bff',      # اللون الأساسي
    'secondary_color': '#28a745',    # اللون الثانوي
    'background_color': '#f8f9fa',   # لون الخلفية
    'text_color': '#333333'          # لون النص
}

# إعدادات قاعدة البيانات
DATABASE_SETTINGS = {
    'excel_file': 'database.xlsx',
    'backup_file': 'database_backup.csv',
    'auto_backup': True              # نسخة احتياطية تلقائية
}

# رسائل مخصصة
MESSAGES = {
    'welcome': 'مرحباً بك في نظام إدارة السيارات',
    'login_error': 'بيانات دخول غير صحيحة',
    'success': 'تم بنجاح!',
    'error': 'حدث خطأ، يرجى المحاولة مرة أخرى'
}

def get_setting(category, key):
    """دالة للحصول على إعداد معين"""
    settings_map = {
        'app': APP_SETTINGS,
        'design': DESIGN_SETTINGS,
        'database': DATABASE_SETTINGS,
        'messages': MESSAGES
    }
    return settings_map.get(category, {}).get(key, '')
