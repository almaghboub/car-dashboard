
from flask import Flask, render_template, request, redirect, url_for, session
import pandas as pd
import os
from my_settings import APP_SETTINGS, DATABASE_SETTINGS, MESSAGES, get_setting

app = Flask(__name__)
app.secret_key = 'change_this_secret'

def load_data():
    # Check if Excel file exists, if not create it from CSV
    if os.path.exists('database.xlsx'):
        return pd.read_excel('database.xlsx', dtype=str)
    elif os.path.exists('database.csv'):
        # Convert CSV to Excel for first time
        df = pd.read_csv('database.csv', dtype=str)
        df.to_excel('database.xlsx', index=False)
        return df
    else:
        # Create empty DataFrame with columns
        columns = ['الاسم', 'الرقم الخاص', 'شحن الخارجي', 'التاريخ', 'شحن الداخلي', 
                  'VIN', 'اللوت', 'رقم الهيكل', 'سنة الصنع', 'الباقي', 'المجموع', 
                  'رقم الحاوية', 'العمولة', 'قيمة الشراء']
        df = pd.DataFrame(columns=columns)
        df.to_excel('database.xlsx', index=False)
        return df

def save_data(df):
    df.to_excel('database.xlsx', index=False)

@app.route('/', methods=['GET','POST'])
def login():
    error = None
    if request.method == 'POST':
        name = request.form['name']
        code = request.form['code']
        df = load_data()
        user = df[(df['الاسم']==name) & (df['الرقم الخاص']==code)]
        if not user.empty:
            session['user'] = name
            return redirect(url_for('dashboard'))
        error = MESSAGES['login_error']
    return render_template('login.html', error=error)

@app.route('/dashboard')
def dashboard():
    if 'user' not in session:
        return redirect(url_for('login'))
    name = session['user']
    df = load_data()
    user_cars = df[(df['الاسم']==name)]
    return render_template('dashboard.html', cars=user_cars.to_dict(orient='records'), user_name=name)

@app.route('/test')
def test():
    return '<h1>Flask App is Working!</h1><p>Go to <a href="/">Login Page</a></p>'

@app.route('/admin', methods=['GET','POST'])
def admin():
    admin_password = APP_SETTINGS['admin_password']
    if request.method == 'POST':
        password = request.form.get('password')
        if password == admin_password:
            df = load_data()
            return render_template('admin.html', records=df.to_dict(orient='records'), message=None)
        else:
            return render_template('admin.html', records=[], message='كلمة مرور غير صحيحة')
    
    return render_template('admin.html', records=[], message=None)

@app.route('/convert_to_excel')
def convert_to_excel():
    """Convert existing CSV to Excel format"""
    if os.path.exists('database.csv'):
        df = pd.read_csv('database.csv', dtype=str)
        df.to_excel('database.xlsx', index=False)
        return f'<h2>✅ تم تحويل البيانات إلى Excel بنجاح!</h2><p>يمكنك الآن تعديل ملف database.xlsx مباشرة</p><p>أي تغيير في الملف سيظهر للعملاء فوراً</p><a href="/admin">العودة لوحة التحكم</a>'
    else:
        return '<h2>❌ لم يتم العثور على ملف CSV</h2><a href="/admin">العودة لوحة التحكم</a>'

@app.route('/add_car', methods=['GET','POST'])
def add_car():
    if request.method == 'POST':
        # Get form data
        new_car = {
            'الاسم': request.form['name'],
            'الرقم الخاص': request.form['code'],
            'شحن الخارجي': request.form['external_shipping'],
            'التاريخ': request.form['date'],
            'شحن الداخلي': request.form['internal_shipping'],
            'VIN': request.form['vin'],
            'اللوت': request.form['lot'],
            'رقم الهيكل': request.form['chassis'],
            'سنة الصنع': request.form['year'],
            'الباقي': request.form['remaining'],
            'المجموع': request.form['total'],
            'رقم الحاوية': request.form['container'],
            'العمولة': request.form['commission'],
            'قيمة الشراء': request.form['purchase_value']
        }
        
        # Load existing data and add new car
        df = load_data()
        new_df = pd.concat([df, pd.DataFrame([new_car])], ignore_index=True)
        save_data(new_df)
        
        return redirect(url_for('admin'))
    
    return render_template('add_car.html')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
